# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| Latest   | :white_check_mark: |

## Reporting a Vulnerability

Report all Vulnerabilities by submitting an issue.
